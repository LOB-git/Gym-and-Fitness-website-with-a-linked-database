<!--
* Group 15: Yuan Tang,Lishu Yuan
* Date: 2023-03-27
* Section: CST 8285 section 302
* Description: the footer page
-->

<footer>
    <p>&copy; 2024 Fitness Center</p>
    <p>Location: 123 ABC Crescent, Ottawa, ON K1A 1A1
    <p>
</footer>